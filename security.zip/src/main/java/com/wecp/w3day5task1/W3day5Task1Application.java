package com.wecp.w3day5task1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class W3day5Task1Application {

	public static void main(String[] args) {
		SpringApplication.run(W3day5Task1Application.class, args);
	}

}
