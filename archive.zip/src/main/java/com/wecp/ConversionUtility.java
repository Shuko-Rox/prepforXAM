package com.wecp;

import java.util.ArrayList;
import java.util.List;

public class ConversionUtility {
    // implement conversion functions here
}
