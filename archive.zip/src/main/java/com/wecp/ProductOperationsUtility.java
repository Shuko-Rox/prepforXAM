package com.wecp;

public class ProductOperationsUtility {

    // implement product operation functions here

}
