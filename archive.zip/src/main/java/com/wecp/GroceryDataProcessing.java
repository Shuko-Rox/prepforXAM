package com.wecp;

import java.util.Comparator;

public class GroceryDataProcessing {

    public static void main(String[] args) {
        // call the methods to process the data here
    }
}